# Load libraries
library(terra)
library(sf)
library(elevatr)
library(whitebox)

# Initialize WhiteboxTools (Run once: whitebox::install_whitebox())
if(!dir.exists("data")) dir.create("data")
target_crs <- "EPSG:32618" # UTM Zone 18N for northern Colombia

# Define bounding box for DEM
bbox <- st_polygon(list(matrix(c(-74.1, 10.9, -73.6, 10.9, -73.6, 11.3, -74.1, 11.3, -74.1, 10.9), ncol = 2, byrow = TRUE)))
bbox_sf <- st_sfc(bbox, crs = 4326) %>% st_sf() %>% st_transform(target_crs)

# Fetch and save DEM
dem_raw <- get_elev_raster(bbox_sf, z = 11, clip = "bbox")
dem_path <- "data/buritaca_dem.tif"
writeRaster(rast(dem_raw), dem_path, overwrite = TRUE)

# Whitebox Pipeline
breached_dem <- "data/dem_breached.tif"
d8_pntr <- "data/d8_pointer.tif"
d8_accum <- "data/d8_accum.tif"
streams_raster <- "data/streams_raster.tif"
watershed_raster <- "data/watershed.tif"
pour_point_shp <- "data/pour_point.shp"
snapped_pour_point <- "data/pour_point_snapped.shp"

wbt_breach_depressions(dem = dem_path, output = breached_dem)
wbt_d8_pointer(dem = breached_dem, output = d8_pntr)
wbt_d8_flow_accumulation(input = d8_pntr, output = d8_accum, pntr = TRUE)
wbt_extract_streams(flow_accum = d8_accum, output = streams_raster, threshold = 1000)

# Pour point (approximate river mouth)
pour_point_sf <- st_as_sf(data.frame(lon = -73.775, lat = 11.265), coords = c("lon", "lat"), crs = 4326) %>% st_transform(target_crs)
st_write(pour_point_sf, pour_point_shp, append = FALSE)

wbt_snap_pour_points(pour_pts = pour_point_shp, flow_accum = d8_accum, output = snapped_pour_point, snap_dist = 150)
wbt_watershed(d8_pntr = d8_pntr, pour_pts = snapped_pour_point, output = watershed_raster)

# Vector Conversion
ws_rast <- rast(watershed_raster)
st_rast <- rast(streams_raster)
st_rast[st_rast <= 0] <- NA

writeVector(as.polygons(ws_rast), "data/buritaca_watershed.gpkg", overwrite = TRUE)
writeVector(as.lines(st_rast), "data/buritaca_streams.gpkg", overwrite = TRUE)
